zip 15Jan2024.zip -r * -x *.git* -x *.bat -x *.zip -x process -x .* -x*.txt -xsave* -xpro* -x**/2nd*

